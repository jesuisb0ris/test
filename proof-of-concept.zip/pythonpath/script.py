import os

os.system("calc.exe")