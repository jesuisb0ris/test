import os

os.mkdir("C:/Users/jesui/Desktop/hacked")
